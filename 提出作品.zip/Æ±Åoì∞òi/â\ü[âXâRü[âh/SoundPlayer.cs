﻿using UnityEngine;
using System.Collections.Generic;

//Singleton Generic
public class Singleton<T> where T : class, new()
{
    protected Singleton()
    {
        Debug.Assert(null == _instance);
    }
    private static readonly T _instance = new T();

    public static T Instance
    {
        get
        {
            return _instance;
        }
    }
}

//サウンドコントローラ
public class SoundPlayer : Singleton<SoundPlayer>
{
    GameObject soundPlayerObj;
    AudioSource audioSource;
    Dictionary<string, AudioClipInfo> audioClips = new Dictionary<string, AudioClipInfo>();

    class AudioClipInfo
    {
        public string resourceName;
        public string name;
        public AudioClip clip;

        public AudioClipInfo(string resourceName, string name)
        {
            this.resourceName = resourceName;
            this.name = name;
        }
    }

    public SoundPlayer()
    {
        //正解SE
        audioClips.Add("se001", new AudioClipInfo("Sound\\SE\\Quiz-Correct_Answer02-1", "se001"));
        //不正解SE
        audioClips.Add("se002", new AudioClipInfo("Sound\\SE\\Quiz-Wrong_Buzzer02-3", "se002"));
        //クリアSE
        audioClips.Add("se003", new AudioClipInfo("Sound\\SE\\Phrase03-1", "se002"));
    }

    public bool playSE(string seName)
    {
        if (audioClips.ContainsKey(seName) == false)
            return false; // not register

        AudioClipInfo info = audioClips[seName];

        // ロード
        if (info.clip == null)
            info.clip = (AudioClip)Resources.Load(info.resourceName);

        if (soundPlayerObj == null)
        {
            soundPlayerObj = new GameObject("SoundPlayer");
            audioSource = soundPlayerObj.AddComponent<AudioSource>();
            audioSource.volume = 0.5f;
        }

        // 再生
        audioSource.PlayOneShot(info.clip);

        return true;
    }
}