﻿using System;
using System.Collections;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

public enum Mark : byte
{
    Heart,
    Diamond,
    Spade,
    Clover,
}

public static class MarkExt
{

    public static string ObtainStatus(this Mark value)
    {
        switch (value)
        {
            case Mark.Heart: return "Heart";
            case Mark.Diamond: return "Diamond";
            case Mark.Spade: return "Spade";
            case Mark.Clover: return "Clover";
        }
        return null;
    }
}

//カードクラス
public class Cards
{
    private string mark;
    private int number;
    private bool isOpen;
    private GameObject card;

    public string Mark
    {
        get
        {
            return mark;
        }

        set
        {
            mark = value;
        }
    }
    public int Number
    {
        get
        {
            return number;
        }

        set
        {
            number = value;
        }
    }
    public GameObject Card
    {
        get
        {
            return card;
        }

        set
        {
            card = value;
        }
    }
    public bool IsOpen
    {
        get
        {
            return isOpen;
        }

        set
        {
            isOpen = value;
        }
    }
}

public class Main : MonoBehaviour
{
    const string TEXTURE_PASS = "Sprite";
    //カード枚数
    const int C_NUM = 52;
    private int[,] r_pos;
    private int count;
    private bool isSecond;
    private Sprite[] sprites;
    private Cards[] cards;
    private Cards firstCard;

    //初期化
    void Start()
    {
        isSecond = false;
        //Sprite読み込み
        sprites = Resources.LoadAll<Sprite>(TEXTURE_PASS);
        cards = new Cards[C_NUM];
        firstCard = null;
        count = 0;

        //カメラ位置設定
        GameObject mainCamera = GameObject.FindGameObjectWithTag("MainCamera");
        mainCamera.transform.localPosition = new Vector3(12.0f, 3.0f, -1.0f);
        mainCamera.transform.localEulerAngles = new Vector3(0, 0, 0);
        mainCamera.transform.localScale = new Vector3(1, 1, 1);
        Camera camera = mainCamera.GetComponent<Camera>();
        camera.enabled = true;
        camera.orthographicSize = 8 * (1.0f / (((float)Screen.width / (float)Screen.height) / (1440.0f / 900.0f)));

        //カード情報生成
        for (int i = 0; i <= C_NUM - 1; i++)
        {
            cards[i] = new Cards();
            cards[i].Number = ((i + 1) % 13) + 1;
            cards[i].Mark = MarkExt.ObtainStatus((Mark)(i / 13));
        }

        //シャッフル
        cards = cards.OrderBy(i => Guid.NewGuid()).ToArray();

        //プレハブ作成
        for (int i = 0; i <= C_NUM - 1; i++)
        {
            cards[i].Card = Instantiate(Resources.Load("Prefabs/CardBuck"), new Vector3((((i + 1) % 13) * 2.0f), ((i / 13) * 2.0f), 0.0f), Quaternion.identity) as GameObject;
            cards[i].Card.AddComponent<BoxCollider2D>().isTrigger = true;
            cards[i].Card.name = "Card" + " " + cards[i].Mark + " " + cards[i].Number;
        }


    }
    
    void Update()
    {
        //左クリック検出
        if (Input.GetMouseButtonDown(0))
        {
            Vector2 tapPoint = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            Collider2D collider = Physics2D.OverlapPoint(tapPoint);

            if (collider != null)
            {

                foreach (Cards n in cards)
                {
                    if (n.Card == collider.gameObject)
                    {
                        //表裏判定
                        if (n.IsOpen == true || firstCard == n)
                        {
                            break;
                        }

                        n.IsOpen = true;
                        //Spriteを表面に差し替え
                        n.Card.GetComponent<SpriteRenderer>().sprite = Array.Find<Sprite>(sprites, (sprite) => sprite.name.Equals(n.Mark + n.Number));

                        //二枚目判定
                        if (isSecond == true)
                        {
                            //一致判定
                            if (firstCard.Number == n.Number)
                            {
                                //正解SEをプレイ
                                Singleton<SoundPlayer>.Instance.playSE("se001");
                                count++;

                                //ゲーム終了判定
                                if (count == 26)
                                {
                                    //ゲーム終了用コルーチンスタート
                                    StartCoroutine(GameClear());
                                }

                            }
                            else
                            {
                                //不正解SEをプレイ
                                Singleton<SoundPlayer>.Instance.playSE("se002");
                                //不正解処理用コルーチンスタート
                                StartCoroutine(Incorrect(firstCard, n));
                            }
                            //2枚目終了処理
                            isSecond = false;
                            firstCard = null;
                        }
                        else
                        {
                            //1枚目終了処理
                            isSecond = true;
                            firstCard = n;
                        }
                    }
                }
            }
        }
    }

    //不正解用コルーチン
    IEnumerator Incorrect(Cards a, Cards b)
    {
        //二秒後に不正解処理
        yield return new WaitForSeconds(2);
        //Spriteを裏面に差し替え
        a.Card.GetComponent<SpriteRenderer>().sprite = System.Array.Find<Sprite>(sprites, (sprite) => sprite.name.Equals("bk0"));
        b.Card.GetComponent<SpriteRenderer>().sprite = System.Array.Find<Sprite>(sprites, (sprite) => sprite.name.Equals("bk0"));
        a.IsOpen = false;
        b.IsOpen = false;
    }

    //ゲーム終了用コルーチン
    IEnumerator GameClear()
    {
        //ゲーム終了用SEをプレイ
        Singleton<SoundPlayer>.Instance.playSE("se003");

        //クリア画像を描画
        var canvasObject = new GameObject("Canvas");
        var canvas = canvasObject.AddComponent<Canvas>();
        canvas.transform.localPosition = new Vector3(15, 1, 0); ;
        canvas.sortingOrder = 1;
        GameObject work_image = new GameObject("WorkImage");
        work_image.transform.parent = GameObject.Find("Canvas").transform;
        work_image.AddComponent<RectTransform>().anchoredPosition = new Vector3(0, 0, 0);
        work_image.GetComponent<RectTransform>().localScale = new Vector3(0.7f, 0.7f, 1.0f);
        work_image.AddComponent<Image>().sprite = Array.Find<Sprite>(sprites, (sprite) => sprite.name.Equals("GameClear2"));
        work_image.GetComponent<Image>().preserveAspect = true;

        //2秒後にタイトルSceneをロード
        yield return new WaitForSeconds(2);
        Application.LoadLevel("title");
    }
}